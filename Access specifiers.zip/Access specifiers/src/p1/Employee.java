package p1;

public class Employee {
	//public and protected can be accessed by extended of another package
	public int age;
	protected String name;
	protected float sal;
	protected String dept;

}
