package p2;

import java.util.Scanner;

import p1.Employee;

class Contractor extends Employee{
	
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		name=sc.next();
		System.out.println("Enter age");
		age=sc.nextInt();
		
	}
	void display() {
		System.out.println("name= "+name);
		System.out.println("Age= "+age);
		
	}
}

public class MainClass {

	public static void main(String[] args) {
		Contractor ob=new Contractor();

	}

}
