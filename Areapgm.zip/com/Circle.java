package pack.com;

public class Circle {

	public static void main(String[] args) {
		int r,area;
		double pi=3.142,a;
		r=5;
		a=pi*r*r;
		System.out.println(" Area of circle is "+a);
		

	}

}
