package pack.com;

public class Rectangle {

	public static void main(String[] args) {
		int l,b,ar;
		l=98;
		b=76;
		ar=l*b;
		System.out.println("The area of rectangle of length "+l+" and breadth "+b+" is "+ar);

	}

}
