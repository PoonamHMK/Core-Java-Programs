package pack.com;

public class Square {

	public static void main(String[] args) {
		int s,a;
		s=5;
		a=s*s;
		System.out.println(" The area of square is "+a);
		
		

	}

}
