package pack.com;

public class Triangle {

	public static void main(String[] args) {
		int b,h,a;
		b=5;
		h=10;
		a=(b*h)/2;
		System.out.println(" The area of triangle is "+a);

	}

}
